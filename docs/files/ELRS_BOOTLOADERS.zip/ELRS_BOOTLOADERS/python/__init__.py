import binary_configurator

if __name__ == '__main__':
    binary_configurator.main()
